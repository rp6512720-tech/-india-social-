INDIA SOCIAL — Clickable UI Prototype

Open index.html in a browser on a phone or computer.
This is a front-end visual prototype: navigation, game cards and room buttons show demo interactions.
It does NOT yet include real accounts, messaging, multiplayer games, live voice, payments or a production database.
Those require backend services and integration work.
